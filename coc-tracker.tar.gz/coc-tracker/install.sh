#!/usr/bin/env bash
set -e

EXT_ID="coc-tracker@zorro"
EXT_DIR="$HOME/.local/share/gnome-shell/extensions/$EXT_ID"

echo "Installing $EXT_ID..."
mkdir -p "$EXT_DIR"
cp -r "$(dirname "$0")/$EXT_ID/." "$EXT_DIR/"

echo "Enabling extension..."
gnome-extensions enable "$EXT_ID" 2>/dev/null || true

echo "Done. Reload GNOME Shell (Alt+F2 → r → Enter, or log out/in on Wayland)."
echo "Then run: gnome-extensions enable $EXT_ID"
